OFFLINE COURSE PACK

IMPORTANT — fully extract this ZIP before opening it.
1. Extract the whole ZIP to a folder.
2. Open index.html from the extracted folder.
3. Keep the resources folder beside index.html.

Course: States of Matter
Version: 2.31.2
This pack includes all modules in the project.
Teacher 5E planning data is intentionally excluded from this student package.
